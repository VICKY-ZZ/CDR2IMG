import numpy as np

# y_fraud = np.ones((1892), dtype='int')
# y_non_fraud = np.zeros((4133), dtype='int')

all= np.load('./hour_trail/all.npz')

Y = all['Y']
X = all['X']

# X_SC1:P=900;N=900
SC1_X_P = X[:900]
SC1_Y_P = Y[:900]

SC1_X_N = X[1892:(1892+900)]
SC1_Y_N = Y[1892:(1892+900)]

SC1_X = np.concatenate((SC1_X_P, SC1_X_N), axis=0)
SC1_Y = np.concatenate((SC1_Y_P, SC1_Y_N), axis=0)

np.savez_compressed('./Different_P_N_Ratio/SC1', X=SC1_X, Y=SC1_Y)

#------------------------------------------------------------------------------

# X_SC5:P=900;N=2100
SC5_X_P = X[:900]
SC5_Y_P = Y[:900]

SC5_X_N = X[1892:(1892+2100)]
SC5_Y_N = Y[1892:(1892+2100)]

SC5_X = np.concatenate((SC5_X_P, SC5_X_N), axis=0)
SC5_Y = np.concatenate((SC5_Y_P, SC5_Y_N), axis=0)

np.savez_compressed('./Different_P_N_Ratio/SC5', X=SC5_X, Y=SC5_Y)

#------------------------------------------------------------------------------

# X_SC10:P=900;N=3600
SC10_X_P = X[:900]
SC10_Y_P = Y[:900]

SC10_X_N = X[1892:(1892+3600)]
SC10_Y_N = Y[1892:(1892+3600)]

SC10_X = np.concatenate((SC10_X_P, SC10_X_N), axis=0)
SC10_Y = np.concatenate((SC10_Y_P, SC10_Y_N), axis=0)

np.savez_compressed('./Different_P_N_Ratio/SC10', X=SC10_X, Y=SC10_Y)
